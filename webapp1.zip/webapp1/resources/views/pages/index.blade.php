@extends('layouts.app1')
@section('content')
<h1>Index</h1>
<h2><?php echo $title;?>
<p>This is my index page<p>
@endsection