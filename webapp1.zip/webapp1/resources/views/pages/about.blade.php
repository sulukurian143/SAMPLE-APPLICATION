
@extends('layouts.app1')
@section('content')
<h1>About</h1>
<p>Myself Sulu Kurian </p>
@endsection