@extends('layouts.app1')
@section('content')
<h1>Services</h1>
<p>This is my new page<p>
@endsection