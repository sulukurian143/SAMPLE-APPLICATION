<form method="post" action="{{route('book.update',$books->id)}}">
@csrf
<input type="text" name="title" value={{$books->title}}/>
<input type="text" name="body" value={{$books->body}}/>
<button type="submit">Update</button>
</form>