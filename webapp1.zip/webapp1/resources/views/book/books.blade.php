<form method="post" action="{{route('book.store')}}">
@csrf
Title<input type="text" name="title"><br>
Body
<input type="text" name="body">
<button type="submit">ADD</button>
</form>