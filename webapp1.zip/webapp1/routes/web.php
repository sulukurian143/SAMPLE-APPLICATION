<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/abt', function () {
    return view('pages.about');
});
Route::get('/users/{id}', function ($id) {
    return 'hai my id is' .$id;
});
Route::get('/create', function () {
     return view('book.books');
});
Route::get('/index', function () {
     return view('book.books');
});
Route::get('/hello', function () {
    return "<h1>hi sulu</h1>";
});
//Route::get('/index', 'PagesController@index');
Route::get('/index', 'BooksController@index');
Route::get('/services', 'PagesController@service');
Route::get('/about', 'PagesController@about');
Route::get('/sample', 'BooksController@sample');
Route::resource('/book','BooksController');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
