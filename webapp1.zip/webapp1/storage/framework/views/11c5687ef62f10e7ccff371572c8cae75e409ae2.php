<form method="post" action="<?php echo e(route('book.update',$books->id)); ?>">
<?php echo csrf_field(); ?>
<input type="text" name="title" value=<?php echo e($books->title); ?>/>
<input type="text" name="body" value=<?php echo e($books->body); ?>/>
<button type="submit">Update</button>
</form>