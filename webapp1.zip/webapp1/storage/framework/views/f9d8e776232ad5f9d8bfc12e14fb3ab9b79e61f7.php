<html>
<body>
  <div>
    <a href="/index">Home</a>
	<a href="/services">Services</a>
	<a href="/about">About</a>
  </div>
  <?php echo $__env->yieldContent('content'); ?>   
</body>
</html>