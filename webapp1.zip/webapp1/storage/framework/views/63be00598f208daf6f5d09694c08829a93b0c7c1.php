<?php $__env->startSection('content'); ?>
<h1>Services</h1>
<p>This is my new page<p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>