<form method="post" action="<?php echo e(route('book.store')); ?>">
<?php echo csrf_field(); ?>
Title<input type="text" name="title"><br>
Body
<input type="text" name="body">
<button type="submit">ADD</button>
</form>