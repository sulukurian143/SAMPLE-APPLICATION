<table>
<tr>
<thead>
<td>Id</td>
<td>title</td>
<td>body</td>
</thead>
</tr>
<tbody>
<?php $__currentLoopData = $booksdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($book->id); ?></td>
<td><?php echo e($book->title); ?></td>
<td><?php echo e($book->body); ?></td>
<td>
<a href="<?php echo e(route('book.edit',$book->id)); ?>">Edit</a>
</td>
<td>
<form action="<?php echo e(route('book.destroy',$book->id)); ?>" method="post">
<?php echo csrf_field(); ?>
<?php echo method_field('DELETE'); ?>
<button type="submit">DELETE</button>
</form></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>